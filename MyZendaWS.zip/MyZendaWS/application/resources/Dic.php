<?php


use Symfony\Component\DependencyInjection\ContainerBuilder;
use Symfony\Component\Config\FileLocator;
use Symfony\Component\DependencyInjection\Loader\YamlFileLoader;

class Aws_Resource_Dic extends Zend_Application_Resource_ResourceAbstract
{
    /**
     * Initialise le conteneur d'injection de dépendances de Symfony
     * et le mémorise dans le container du bootstrap Zend
     * @return \Symfony\Component\DependencyInjection\ContainerBuilder
     */
    public function init()
    {
        $options = $this->getOptions();
        $container = new ContainerBuilder();
        $configFile = basename($options['configfile']); 
        $loader = new YamlFileLoader($container, new FileLocator(dirname($options['configfile'])));
        $loader->load($configFile);
        return $container;
    }
    
}