<?php

require_once ROOT_PATH . '/vendor/autoload.php';


class Bootstrap extends Zend_Application_Bootstrap_Bootstrap
{

  protected function _initMonService()
    {
    }

}

