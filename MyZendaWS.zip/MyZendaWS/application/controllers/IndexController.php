<?php

class IndexController extends Zend_Controller_Action
{

    
        /**
     * Stocke l'instance du conteneur d'injection de dépendances
     * @var \Symfony\Component\DependencyInjection\ContainerBuilder
     */
    protected $_container;
    
    public function init()
    {
        /* Initialize action controller here */
        $this->_container = $this->getFrontController()->getParam('bootstrap')->getResource('dic') ; 
    }

    public function indexAction()
    {
        // action body
        
        print $this->_container->get('domain.service.exemple')->sayHello() ; 
    }


}

